package Q1;

public class TicketBenchmark {
    public static String buildWithPlus(String[] fields) {
        String ticket = "";
        for (String f : fields) ticket = ticket + f + "|";
        return ticket;
    }
    public static String buildWithBuilder(String[] fields) {
        StringBuilder sb = new StringBuilder(fields.length * 16);
        for (String f : fields) sb.append(f).append('|');
        return sb.toString();
    }
    public static String buildWithBuffer(String[] fields) {
        StringBuffer sbf = new StringBuffer(fields.length * 16);
        for (String f : fields) sbf.append(f).append('|');
        return sbf.toString();
    }
    public static void runWorkload(String label, int tickets, int fieldCount) {
        String[] fields = new String[fieldCount];
        for (int i = 0; i < fieldCount; i++) fields[i] = "FIELD_" + i + "_VAL";
        long t1 = System.nanoTime();
        for (int t = 0; t < tickets; t++) buildWithPlus(fields);
        long plusMs = (System.nanoTime() - t1) / 1_000_000;
        long t2 = System.nanoTime();
        for (int t = 0; t < tickets; t++) buildWithBuilder(fields);
        long sbMs = (System.nanoTime() - t2) / 1_000_000;
        long t3 = System.nanoTime();
        for (int t = 0; t < tickets; t++) buildWithBuffer(fields);
        long sbfMs = (System.nanoTime() - t3) / 1_000_000;
        System.out.printf("%s -> String(+): %d ms | StringBuilder: %d ms | StringBuffer: %d ms%n", label, plusMs, sbMs, sbfMs);
    }
    public static void main(String[] args) {
        runWorkload("W1 (1 ticket, 10 fields)", 1, 10);
        runWorkload("W2 (10,000 tickets, 50 fields)", 10_000, 50);
        runWorkload("W3 (25,000 tickets, 80 fields)", 25_000, 80);
    }
}
