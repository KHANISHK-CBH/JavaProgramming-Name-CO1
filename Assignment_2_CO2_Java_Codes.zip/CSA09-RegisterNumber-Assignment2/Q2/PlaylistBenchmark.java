package Q2;

import java.util.*;

public class PlaylistBenchmark {
    public static void benchmark(int n) {
        List<String> arrayList = new ArrayList<>();
        List<String> linkedList = new LinkedList<>();
        Deque<String> arrayDeque = new ArrayDeque<>();
        long t0 = System.nanoTime();
        for (int i = 0; i < n; i++) arrayList.add("Song-" + i);
        long alEnd = System.nanoTime() - t0;
        t0 = System.nanoTime();
        for (int i = 0; i < n; i++) linkedList.add("Song-" + i);
        long llEnd = System.nanoTime() - t0;
        t0 = System.nanoTime();
        for (int i = 0; i < n; i++) arrayDeque.addLast("Song-" + i);
        long adEnd = System.nanoTime() - t0;
        System.out.printf("Size=%d | AddEnd(ns): AL=%d, LL=%d, AD=%d%n", n, alEnd, llEnd, adEnd);
    }
    public static void main(String[] args) {
        benchmark(1_000); benchmark(10_000); benchmark(50_000);
    }
}
