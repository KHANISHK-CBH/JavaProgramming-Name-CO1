package Q7;

import java.util.Comparator;
import java.util.PriorityQueue;

public class FairTriageSystem {
    static class AgedPatient {
        final String name; final int baseSeverity; final long arrivalTick;
        AgedPatient(String name, int baseSeverity, long arrivalTick) {
            this.name = name; this.baseSeverity = baseSeverity; this.arrivalTick = arrivalTick;
        }
        int effectiveSeverity(long nowTick) {
            int boost = (int) (Math.max(0, nowTick - arrivalTick) / 10);
            return Math.max(1, baseSeverity - boost);
        }
    }
    private long currentTick = 0;
    private final PriorityQueue<AgedPatient> pq = new PriorityQueue<>(
            Comparator.comparingInt((AgedPatient p) -> p.effectiveSeverity(currentTick)).thenComparingLong(p -> p.arrivalTick)
    );
    public void admit(String name, int severity) { pq.offer(new AgedPatient(name, severity, currentTick++)); }
    public AgedPatient treatNext() {
        currentTick++;
        if (!pq.isEmpty()) { AgedPatient h = pq.poll(); pq.offer(h); }
        return pq.poll();
    }
    public static void main(String[] args) {
        FairTriageSystem triage = new FairTriageSystem();
        triage.admit("Asha_Minor", 5);
        for (int i = 1; i <= 45; i++) {
            triage.admit("Critical_" + i, 1);
            if (i % 5 == 0) {
                AgedPatient treated = triage.treatNext();
                if (treated != null && treated.name.equals("Asha_Minor"))
                    System.out.println("Treated without starvation: " + treated.name);
            }
        }
    }
}
