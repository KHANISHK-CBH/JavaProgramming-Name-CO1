package Q4;

import java.util.*;

public class PharmacyInventory {
    public static void testSize(int n) {
        Map<String, Integer> hashMap = new HashMap<>();
        Map<String, Integer> linkedMap = new LinkedHashMap<>();
        Map<String, Integer> treeMap = new TreeMap<>();
        List<String> codes = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            String code = String.format("MED%06d", (i * 7919) % (n * 10));
            codes.add(code);
            hashMap.put(code, 50); linkedMap.put(code, 50); treeMap.put(code, 50);
        }
        Random rnd = new Random(42);
        long t0 = System.nanoTime();
        for (int i = 0; i < 100_000; i++) hashMap.get(codes.get(rnd.nextInt(n)));
        long hmLookup = (System.nanoTime() - t0) / 1_000_000;
        t0 = System.nanoTime();
        for (int i = 0; i < 100_000; i++) linkedMap.get(codes.get(rnd.nextInt(n)));
        long lhmLookup = (System.nanoTime() - t0) / 1_000_000;
        t0 = System.nanoTime();
        for (int i = 0; i < 100_000; i++) treeMap.get(codes.get(rnd.nextInt(n)));
        long tmLookup = (System.nanoTime() - t0) / 1_000_000;
        System.out.printf("Medicines=%d | 100k Lookups -> HashMap: %d ms, LinkedHashMap: %d ms, TreeMap: %d ms%n",
                n, hmLookup, lhmLookup, tmLookup);
    }
    public static void main(String[] args) { testSize(500); testSize(5_000); testSize(50_000); }
}
