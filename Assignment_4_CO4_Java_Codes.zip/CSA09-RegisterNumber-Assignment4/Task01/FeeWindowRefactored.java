package Task01;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class FeeService {
    public String processPayment(String regNo, String amountText) {
        if (regNo == null || regNo.isBlank()) throw new IllegalArgumentException("Registration number required.");
        double amt = Double.parseDouble(amountText.trim());
        if (amt <= 0) throw new IllegalArgumentException("Amount must be positive.");
        return "Receipt#" + System.currentTimeMillis() + " | RegNo: " + regNo + " | Paid: Rs " + amt;
    }
}

public class FeeWindowRefactored extends JFrame {
    private final JTextField regNo = new JTextField(12);
    private final JTextField amount = new JTextField(10);
    private final JLabel status = new JLabel("Ready");
    private final FeeService service = new FeeService();

    public FeeWindowRefactored() {
        super("Student Fee Payment");
        setLayout(new FlowLayout());
        JButton pay = new JButton("Pay");
        JButton clear = new JButton("Clear");
        add(new JLabel("RegNo:")); add(regNo);
        add(new JLabel("Amount:")); add(amount);
        add(pay); add(clear); add(status);

        pay.addActionListener(e -> {
            pay.setEnabled(false);
            status.setText("Processing...");
            new SwingWorker<String, Void>() {
                @Override protected String doInBackground() {
                    return service.processPayment(regNo.getText(), amount.getText());
                }
                @Override protected void done() {
                    try { status.setText(get()); }
                    catch (Exception ex) { status.setText("Error: " + ex.getCause().getMessage()); }
                    finally { pay.setEnabled(true); }
                }
            }.execute();
        });
        clear.addActionListener(e -> { regNo.setText(""); amount.setText(""); status.setText("Cleared"); });
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
    }
    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new FeeWindowRefactored().setVisible(true)); }
}
