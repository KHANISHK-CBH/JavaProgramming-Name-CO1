package Task03;

import java.awt.*;
import javax.swing.*;

public class LibrarySearchScreen extends JFrame {
    public LibrarySearchScreen() {
        super("Campus Library Search");
        setLayout(new BorderLayout(6, 6));

        JPanel topPanel = new JPanel(new BorderLayout());
        JLabel title = new JLabel("Campus Library Catalog Search", SwingConstants.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 16));
        topPanel.add(title, BorderLayout.NORTH);

        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchRow.add(new JLabel("Query:"));
        searchRow.add(new JTextField(20));
        searchRow.add(new JComboBox<>(new String[]{"All", "Books", "Journals", "Theses"}));
        searchRow.add(new JButton("Search"));
        topPanel.add(searchRow, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        JTextArea resultsArea = new JTextArea(12, 45);
        add(new JScrollPane(resultsArea), BorderLayout.CENTER);

        JPanel southPanel = new JPanel(new BorderLayout());
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnRow.add(new JButton("Prev"));
        btnRow.add(new JButton("Next"));
        btnRow.add(new JButton("Reserve"));
        southPanel.add(btnRow, BorderLayout.NORTH);
        southPanel.add(new JLabel("Status: Ready"), BorderLayout.SOUTH);
        add(southPanel, BorderLayout.SOUTH);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
    }
    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new LibrarySearchScreen().setVisible(true)); }
}
