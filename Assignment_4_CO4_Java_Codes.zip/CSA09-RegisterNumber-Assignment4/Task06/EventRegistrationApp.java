package Task06;

import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class EventRegistrationApp extends JFrame {
    private final JTextField regField = new JTextField(12);
    private final JTextField nameField = new JTextField(14);
    private final JComboBox<String> eventBox = new JComboBox<>(new String[]{"Hackathon", "RoboWars", "CodeSprint"});
    private final DefaultTableModel model = new DefaultTableModel(new String[]{"RegNo", "Name", "Event"}, 0);
    private final Set<String> uniqueKeys = new HashSet<>();

    public EventRegistrationApp() {
        super("Campus Event Registration");
        setLayout(new BorderLayout(8, 8));
        JPanel form = new JPanel(new FlowLayout());
        form.add(new JLabel("RegNo:")); form.add(regField);
        form.add(new JLabel("Name:")); form.add(nameField);
        form.add(new JLabel("Event:")); form.add(eventBox);
        JButton regBtn = new JButton("Register");
        form.add(regBtn);
        add(form, BorderLayout.NORTH);
        add(new JScrollPane(new JTable(model)), BorderLayout.CENTER);

        regBtn.addActionListener(e -> {
            String r = regField.getText().trim().toUpperCase();
            String n = nameField.getText().trim();
            String ev = (String) eventBox.getSelectedItem();
            if (r.isEmpty() || n.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required.");
                return;
            }
            String key = r + "::" + ev;
            if (!uniqueKeys.add(key)) {
                JOptionPane.showMessageDialog(this, "Duplicate registration rejected for " + r + " in " + ev);
                return;
            }
            model.addRow(new Object[]{r, n, ev});
            regField.setText(""); nameField.setText("");
        });

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(680, 360);
    }
    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new EventRegistrationApp().setVisible(true)); }
}
