package Task11_12;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

interface Pass { double applyDiscount(double rawFee); }
class MonthlyPass implements Pass { @Override public double applyDiscount(double rawFee) { return 0.0; } }
class OneDayPass implements Pass { @Override public double applyDiscount(double rawFee) { return Math.min(rawFee, 100.0); } }
class VisitorPass implements Pass { @Override public double applyDiscount(double rawFee) { return rawFee; } }

interface PricingRule { double computeFee(VehicleBase v, int minutes, LocalTime entryTime); }

class StandardPricingRule implements PricingRule {
    @Override
    public double computeFee(VehicleBase v, int minutes, LocalTime entryTime) {
        if (minutes <= 0) return 0.0;
        int hours = (minutes + 59) / 60;
        if (v instanceof EBike) return 15.0;
        double rate = v.ratePerHour();
        if (v instanceof DeliveryVan && !entryTime.isBefore(LocalTime.of(9, 0)) && entryTime.isBefore(LocalTime.of(17, 0))) {
            rate *= 2.0;
        }
        return hours * rate;
    }
}

abstract class VehicleBase {
    private final String regNo;
    protected VehicleBase(String regNo) { this.regNo = regNo.trim().toUpperCase(); }
    public String getRegNo() { return regNo; }
    public abstract double ratePerHour();
}

class TwoWheelerV extends VehicleBase {
    public TwoWheelerV(String regNo) { super(regNo); }
    @Override public double ratePerHour() { return 10.0; }
}

class CarV extends VehicleBase {
    public CarV(String regNo) { super(regNo); }
    @Override public double ratePerHour() { return 30.0; }
}

class ElectricCarV extends CarV {
    public ElectricCarV(String regNo) { super(regNo); }
    public double chargingFee(int kWh) { return Math.max(0, kWh) * 12.0; }
}

class EBike extends VehicleBase {
    public EBike(String regNo) { super(regNo); }
    @Override public double ratePerHour() { return 15.0; }
}

class DeliveryVan extends CarV {
    public DeliveryVan(String regNo) { super(regNo); }
}

class ParkingTicket {
    private static int counter = 1000;
    private final int ticketId = ++counter;
    private final VehicleBase vehicle;
    private final Pass pass;
    private final int floor, slot;
    private final LocalTime entryTime;

    public ParkingTicket(VehicleBase v, Pass p, int f, int s, LocalTime t) {
        this.vehicle = v; this.pass = p; this.floor = f; this.slot = s; this.entryTime = t;
    }
    public int getTicketId() { return ticketId; }
    public VehicleBase getVehicle() { return vehicle; }
    public Pass getPass() { return pass; }
    public int getFloor() { return floor; }
    public int getSlot() { return slot; }
    public LocalTime getEntryTime() { return entryTime; }
}

public class SmartParkingSystem {
    private final String[][] slots;
    private final Map<String, ParkingTicket> activeTickets = new HashMap<>();
    private final PricingRule rule;
    private double totalCollection = 0.0;

    public SmartParkingSystem(int[] capacities, PricingRule rule) {
        this.slots = new String[capacities.length][];
        for (int i = 0; i < capacities.length; i++) this.slots[i] = new String[capacities[i]];
        this.rule = rule;
    }

    public ParkingTicket enter(VehicleBase v, Pass pass, LocalTime entryTime) {
        if (activeTickets.containsKey(v.getRegNo())) throw new IllegalStateException("Duplicate entry");
        for (int f = 0; f < slots.length; f++) {
            for (int s = 0; s < slots[f].length; s++) {
                if (slots[f][s] == null) {
                    slots[f][s] = v.getRegNo();
                    ParkingTicket t = new ParkingTicket(v, pass, f, s, entryTime);
                    activeTickets.put(v.getRegNo(), t);
                    return t;
                }
            }
        }
        throw new IllegalStateException("Facility Full");
    }

    public double exit(String regNo, int mins, int kWh) {
        ParkingTicket t = activeTickets.remove(regNo.toUpperCase());
        if (t == null) throw new IllegalArgumentException("Ticket not found");
        slots[t.getFloor()][t.getSlot()] = null;
        double fee = t.getPass().applyDiscount(rule.computeFee(t.getVehicle(), mins, t.getEntryTime()));
        if (t.getVehicle() instanceof ElectricCarV ev && kWh > 0) fee += ev.chargingFee(kWh);
        totalCollection += fee;
        return fee;
    }

    public static void main(String[] args) {
        SmartParkingSystem sys = new SmartParkingSystem(new int[]{20, 35, 50, 75, 100}, new StandardPricingRule());
        sys.enter(new TwoWheelerV("TN01AA1001"), new MonthlyPass(), LocalTime.of(8, 30));
        sys.enter(new CarV("TN02BB2002"), new VisitorPass(), LocalTime.of(10, 0));
        sys.enter(new ElectricCarV("TN03CC3003"), new OneDayPass(), LocalTime.of(11, 15));
        sys.enter(new EBike("TN04DD4004"), new VisitorPass(), LocalTime.of(12, 0));
        sys.enter(new DeliveryVan("TN05EE5005"), new VisitorPass(), LocalTime.of(14, 0));

        System.out.println("TwoWheeler: Rs " + sys.exit("TN01AA1001", 120, 0));
        System.out.println("Car: Rs " + sys.exit("TN02BB2002", 130, 0));
        System.out.println("ElectricCar: Rs " + sys.exit("TN03CC3003", 250, 10));
        System.out.println("EBike: Rs " + sys.exit("TN04DD4004", 180, 0));
        System.out.println("DeliveryVan: Rs " + sys.exit("TN05EE5005", 110, 0));
        System.out.println("Total Collection: Rs " + sys.totalCollection);
    }
}
