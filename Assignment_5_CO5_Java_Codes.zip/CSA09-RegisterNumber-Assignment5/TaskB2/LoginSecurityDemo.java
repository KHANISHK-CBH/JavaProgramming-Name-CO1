package TaskB2;

import java.sql.*;

public class LoginSecurityDemo {
    public static boolean safeLogin(Connection con, String id, String pwd) throws SQLException {
        String sql = "SELECT 1 FROM users WHERE id = ? AND pwd = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, id);
            ps.setString(2, pwd);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }
}
