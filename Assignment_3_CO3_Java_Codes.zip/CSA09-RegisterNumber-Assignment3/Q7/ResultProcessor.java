package Q7;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class ResultProcessor {
    public static void main(String[] args) throws InterruptedException {
        int totalFiles = 20;
        ExecutorService pool = Executors.newFixedThreadPool(4);
        ConcurrentHashMap<String, Integer> results = new ConcurrentHashMap<>();
        AtomicInteger failed = new AtomicInteger(0);
        List<Callable<Void>> tasks = new ArrayList<>();
        for (int i = 1; i <= totalFiles; i++) {
            final int id = i;
            tasks.add(() -> {
                try {
                    if (id % 7 == 0) throw new IllegalArgumentException("Corrupt file #" + id);
                    results.put("STU" + id, 70 + (id % 30));
                } catch (Exception ex) {
                    failed.incrementAndGet();
                }
                return null;
            });
        }
        pool.invokeAll(tasks);
        pool.shutdown();
        System.out.println("Processed OK: " + results.size() + " | Failed safely: " + failed.get());
    }
}
