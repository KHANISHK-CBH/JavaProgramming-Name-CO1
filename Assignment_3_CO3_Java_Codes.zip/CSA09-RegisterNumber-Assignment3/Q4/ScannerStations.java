package Q4;

public class ScannerStations {
    static class StationTask implements Runnable {
        private final String stationName;
        private final int scripts;
        StationTask(String stationName, int scripts) { this.stationName = stationName; this.scripts = scripts; }
        @Override public void run() {
            for (int i = 1; i <= scripts; i++) {
                try { Thread.sleep(10); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            }
            System.out.println(stationName + " finished scanning " + scripts + " scripts.");
        }
    }
    public static void main(String[] args) throws InterruptedException {
        Thread[] stations = new Thread[4];
        for (int i = 0; i < 4; i++) {
            stations[i] = new Thread(new StationTask("Scanner-" + (i + 1), 5));
            stations[i].start();
        }
        for (Thread t : stations) t.join();
        System.out.println("All 4 scanner stations completed.");
    }
}
