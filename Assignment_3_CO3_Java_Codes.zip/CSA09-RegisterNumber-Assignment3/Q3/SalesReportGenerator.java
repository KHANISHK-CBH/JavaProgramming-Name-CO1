package Q3;

import java.io.*;
import java.nio.file.*;
import java.util.List;

public class SalesReportGenerator {
    public static void generateSafe(List<Path> storeFiles, Path summaryFile) throws IOException {
        double grandTotal = 0.0;
        try (BufferedWriter writer = Files.newBufferedWriter(summaryFile)) {
            for (Path store : storeFiles) {
                try (BufferedReader reader = Files.newBufferedReader(store)) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        grandTotal += Double.parseDouble(line.trim());
                    }
                }
            }
            writer.write("TOTAL_SALES=" + grandTotal);
            writer.newLine();
        }
    }
    public static void main(String[] args) throws IOException {
        Path s1 = Files.createTempFile("store1", ".txt");
        Path out = Files.createTempFile("summary", ".txt");
        Files.writeString(s1, "1500.50
2499.50
");
        generateSafe(List.of(s1), out);
        System.out.println("Report Output: " + Files.readString(out).trim());
        Files.deleteIfExists(s1); Files.deleteIfExists(out);
    }
}
