package Q1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class InsufficientBalanceException extends Exception {
    public InsufficientBalanceException(String msg) { super(msg); }
}

public class AtmSimulation {
    public static void withdraw(String amountText, double balance, File cardConfig)
            throws FileNotFoundException, InsufficientBalanceException {
        Scanner fileScanner = null;
        try {
            fileScanner = new Scanner(cardConfig);
            double amt = Double.parseDouble(amountText);
            if (amt <= 0) throw new IllegalArgumentException("Withdrawal amount must be positive.");
            if (amt > balance) throw new InsufficientBalanceException("Requested Rs " + amt + " exceeds balance Rs " + balance);
            System.out.println("Dispensed Rs " + amt + " | Remaining Balance: Rs " + (balance - amt));
        } catch (NumberFormatException | IllegalArgumentException e) {
            System.out.println("Input Error: " + e.getMessage());
        } catch (InsufficientBalanceException e) {
            System.out.println("Business Rule Error: " + e.getMessage());
        } finally {
            if (fileScanner != null) fileScanner.close();
            System.out.println("Card ejected safely.");
        }
    }
    public static void main(String[] args) throws Exception {
        File tmp = File.createTempFile("card", ".cfg");
        tmp.deleteOnExit();
        withdraw("500", 2000, tmp);
        withdraw("abc", 2000, tmp);
        withdraw("-50", 2000, tmp);
        withdraw("5000", 2000, tmp);
    }
}
